package com.example.gridview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;

public class ImageAdapter extends BaseAdapter {
    Context cnt;
    public ImageAdapter(MainActivity mainActivity){
            cnt =mainActivity;
    }

    @Override
    public int getCount() {
        return data.length;
    }

    @Override
    public Object getItem(int position) {
        return data.length;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView = new ImageView(cnt);
        imageView.setImageResource(data[position]);
        return imageView;
    }
    private int[] data={
            R.drawable.india,
            R.drawable.iceland,
            R.drawable.israel,
            R.drawable.japan,
            R.drawable.fiji,
            R.drawable.canada,
            R.drawable.australia,
            R.drawable.afghanistan,
    };
}
