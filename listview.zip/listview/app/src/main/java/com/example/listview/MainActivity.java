package com.example.listview;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list;
    ArrayList <String> arrayList;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listview );

        arrayList = new ArrayList<>();
        arrayList.add("krish");
        arrayList.add("jeel ");
        arrayList.add("bhavya");
        arrayList.add("aagnik");
        arrayList.add("jay");
        arrayList.add("ronak");
        arrayList.add("parth");
        arrayList.add("sahil");
        arrayList.add("krenil");
        arrayList.add("abhi");




        arrayAdapter = new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                arrayList
        );

        list.setAdapter(arrayAdapter);
    }
}