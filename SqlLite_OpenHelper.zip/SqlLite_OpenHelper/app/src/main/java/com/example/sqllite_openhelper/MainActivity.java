package com.example.sqllite_openhelper;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText e_name,e_add,e_con;
    Bundle b_add,b_del,b_edit,b_view;

    SQLLite sqlLite;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e_name = findViewById(R.id.name);
        e_add= findViewById(R.id.address);
        e_con = findViewById(R.id.contact);

        b_add = findViewById(R.id.b_add);
        b_del = findViewById(R.id.b_del);
        b_edit = findViewById(R.id.b_edit);
        b_view = findViewById(R.id.b_del);

        sqlLite = new SQLLite(this);




    }
}